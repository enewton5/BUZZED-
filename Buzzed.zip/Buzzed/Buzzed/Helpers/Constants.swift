//
//  Constants.swift
//  Buzzed
//
//  Created by Alexis Adams on 3/15/21.
//

import Foundation
struct Constants {
    
    struct Storyboard {
        
        static let homeViewController = "HomeVC"
        static let RRhomeViewController = "RRHomeVC"
        
    }
    
    
}
