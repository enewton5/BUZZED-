//
//  RRLoginViewController.swift
//  Buzzed
//
//  Created by Alexis Adams on 3/14/21.
//

import UIKit
import Firebase
import FirebaseAuth

class RRLoginViewController: UIViewController {
    
    
    @IBOutlet weak var emailTextField: UITextField!
    

    @IBOutlet weak var passwordTextField: UITextField!
    
    @IBOutlet weak var loginButton: UIButton!

    @IBOutlet weak var errorLabel: UILabel!
    
    @IBOutlet weak var signUpButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        func setUpElements() {
            
            //Hide the error label
            errorLabel.alpha = 0
            
            //Style the elements
            Utilities.styleTextField(emailTextField)
            Utilities.styleTextField(passwordTextField)
            Utilities.styleFilledButton(loginButton)
            

        // Do any additional setup after loading the view.
    
        }

    
    
    }

    
    @IBAction func loginButtonTapped(_ sender: Any) { // TODO: Validate Text Fields
        
        // Create cleaned versions of the text field
        let email = emailTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        let password = passwordTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        
        // Signing in the user
        Auth.auth().signIn(withEmail: email, password: password) { (result, error) in
            
            if error != nil {
                // Couldn't sign in
                self.errorLabel.text = error!.localizedDescription
                self.errorLabel.alpha = 1
            }
            else {
                
                let RRhomeViewController = self.storyboard?.instantiateViewController(identifier: Constants.Storyboard.homeViewController) as? RRHomeViewController
                
                self.view.window?.rootViewController = RRhomeViewController
                self.view.window?.makeKeyAndVisible()
            }
        }
    }
    @IBAction func signUpTapped(_ sender: Any) {
    }
}
